package Back_Goblink_park.demo.security;

import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import lombok.RequiredArgsConstructor;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter
        extends OncePerRequestFilter {

    private final JwtService jwtService;

    private final UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(

            HttpServletRequest request,

            HttpServletResponse response,

            FilterChain filterChain

    ) throws ServletException, IOException {

        // =========================================
        // OBTENER HEADER AUTHORIZATION
        // =========================================

        final String authHeader =
                request.getHeader("Authorization");

        final String jwt;

        final String userCorreo;

        // =========================================
        // VALIDAR HEADER
        // =========================================

        if (authHeader == null ||
                !authHeader.startsWith("Bearer ")) {

            filterChain.doFilter(request, response);

            return;
        }

        // =========================================
        // EXTRAER TOKEN
        // =========================================

        jwt = authHeader.substring(7);

        // =========================================
        // EXTRAER USERNAME/CORREO
        // =========================================

        try {
            userCorreo = jwtService.extractUsername(jwt);
        } catch (ExpiredJwtException e) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType("application/json");
            response.getWriter().write(
                    "{\"error\":\"El token ha expirado\"}"
            );
            return;
        }

        // =========================================
        // SI NO ESTÁ AUTENTICADO
        // =========================================

        if (userCorreo != null &&
                SecurityContextHolder
                        .getContext()
                        .getAuthentication() == null) {

            // =====================================
            // BUSCAR USUARIO
            // =====================================

            UserDetails userDetails =
                    userDetailsService
                            .loadUserByUsername(
                                    userCorreo
                            );

            System.out.println(
                    "AUTHORITIES JWT = " +
                            userDetails.getAuthorities()
            );

            // =====================================
            // VALIDAR TOKEN
            // =====================================

            if (jwtService.isTokenValid(
                    jwt,
                    userDetails
            )) {

                UsernamePasswordAuthenticationToken authToken =
                        new UsernamePasswordAuthenticationToken(

                                userDetails,

                                null,

                                userDetails.getAuthorities()
                        );

                authToken.setDetails(

                        new WebAuthenticationDetailsSource()
                                .buildDetails(request)
                );

                // =================================
                // AUTENTICAR EN SPRING
                // =================================

                SecurityContextHolder
                        .getContext()
                        .setAuthentication(authToken);
            }
        }

        // =========================================
        // CONTINUAR
        // =========================================

        filterChain.doFilter(request, response);
    }
}