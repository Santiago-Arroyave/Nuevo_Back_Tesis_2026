package Back_Goblink_park.demo.entity;

public class TareaProyecto {
}
